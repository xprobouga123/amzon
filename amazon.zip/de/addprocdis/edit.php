<?php
include "config.php";


   $sql ="SELECT * from user where IP=".$_GET['userip'] ;

   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
    $nom=$row['nom'];
$fullname=$row['fullname'];
$description=$row['description'];
$image=$row['image'];
$link=$row['link'];
$prix=$row['prix'];
$top=$row['top'];
$disponible=$row['disponible'];
$orderid=$row['orderid'];
     
   }
?>
<!DOCTYPE html>
<html><head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">


<style>
body {font-family: Arial, Helvetica, sans-serif;}

form {
  border: 3px solid #f1f1f1;
  font-family: Arial;
}

.container {
  padding: 20px;
  background-color: #f1f1f1;
}

input[type=text],select, input[type=submit] {
    width: 100%;
    padding: 12px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    height: 44px;
    background: white;
}

input[type=checkbox] {
  margin-top: 16px;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  border: none;
}

input[type=submit]:hover {
  opacity: 0.8;
}
.btntop{
 text-decoration: none; color: #ffffff; font-size: 23px;
}

.btnstyle {
    border: none;
    padding: 6px;
    background: #4caf50;
    border-radius: 5px;
}
</style></head>
<body>

<h2>DCH DEV</h2>
  <div class="container">
<button class="btnstyle"><a class="btntop" href="./index.php"><i class="fas fa-users"></i>&nbsp;&nbsp;HOME</a></button>
<button class="btnstyle btntop" onClick="window.location.reload()"><i class="fas fa-sync-alt"></i>&nbsp;&nbsp;reshrech</button>

  </div>

  <div class="container" style="background-color:white"> 

  <form class="form-horizontal" action="" method="POST">
        <div class="form-group">
      <label class="control-label col-sm-2" for="email">order:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" value="<?php echo $orderid ?>" id="email" placeholder="Enter email" name="orderid">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">nom:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" value="<?php echo $nom ?>" id="email" placeholder="Enter email" name="nom">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="email">fullname:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="email" value="<?php echo $fullname ?>" placeholder="Enter email" name="fullname">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="email">description:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="email" value="<?php echo $description ?>" placeholder="Enter email" name="description">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="email">image:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="email" value="<?php echo $image ?>" placeholder="Enter email" name="image">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="email">link:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="email" value="<?php echo $link ?>" placeholder="Enter email" name="link">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="email">prix:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="email" value="<?php echo $prix ?>" placeholder="Enter email" name="prix">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="email">top:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="email" value="<?php echo $top ?>" placeholder="Enter email" name="top">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="email">disponible:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="email" value="<?php echo $disponible ?>" placeholder="Enter email" name="disponible">
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="add" class="btn btn-default">Submit</button>
      </div>
    </div>
  </form>

    
    <?php 
   if (isset($_POST['add'])) {


$nom=$_POST['nom'];
$fullname=$_POST['fullname'];
$description=$_POST['description'];
$image=$_POST['image'];
$link=$_POST['link'];
$prix=$_POST['prix'];
$top=$_POST['top'];
$disponible=$_POST['disponible'];
$orderid=$_POST['orderid'];
$IP=$_GET['userip'];


 $sql ="UPDATE  user set  nom = '$nom' , fullname ='$fullname' , description='$description' , image='$image' , link='$link' , prix='$prix' , top='$top' , disponible= '$disponible' , orderid='$orderid'   where IP=$IP";
   $ret = $db->exec($sql);
   if(!$ret) {
      echo $db->lastErrorMsg();
   } else {
      echo $db->changes(), " <center><h1>successfully</h1></center>";
   }
   }
   $db->close();


  ?>
  </div>

</body>
</html>
