<?php
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('db.db');
      }
   }
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      //echo "Opened database successfully\n";
   }


$ip= $_SERVER['REMOTE_ADDR'];
$userip =$_SERVER['REMOTE_ADDR'];

?>