<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

.btntop{
 text-decoration: none; color: #ffffff; font-size: 23px;
}

.btnstyle {
    border: none;
    padding: 6px;
    background: #4caf50;
    border-radius: 5px;
}

</style>
</head>
<body>
<?php
session_start();


   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('db.db');
      }
   }
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      //echo "Opened database successfully\n";
   }
?>
<a href="alyss.php"><button class="btnstyle btntop"><i class="fas fa-sync-alt"></i>&nbsp;&nbsp;Ajouter</button></a><br><br>
<table>
  <tr>
    <th>IP</th>
     <th>order</th>
    <th>nom</th>
    <th>prix</th>
    <th>Delete</th>
  </tr>
  <?php 
   
   $sql ="SELECT * from user;";

   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {

      echo "<tr>";
      echo "<th><a href=edit.php?userip=". $row['IP'] . ">". $row['IP'] . "</a></th>";
       echo "<th>".mb_substr($row['orderid'] , 0 , 20, "utf8" ). "</th>";
      echo "<th>".mb_substr($row['nom'] , 0 , 20, "utf8" ). "</th>";
      echo "<th>".mb_substr($row['prix'] , 0 , 20, "utf8" ). "</th>";
      echo "<th><a href=delete.php?userip=".$row['IP']. "><i class='fas fa-user-minus'></i></a></th>";
      echo "</tr>";

   }
   $db->close();


  ?>
</table>

</body>
</html>
