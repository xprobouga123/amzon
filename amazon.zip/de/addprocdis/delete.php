<?php 
include "config.php";

   $ipofvct = $_GET['userip'];
   $sql ="DELETE  from user where IP='$ipofvct';";

    $ret = $db->exec($sql);
   if(!$ret) {
      echo $db->lastErrorMsg();
   } else {
      echo $db->changes(), " <center><h1>successfully</h1></center>";
      HEADER("Location: index.php");
   }
   $db->close();  
   




  ?>