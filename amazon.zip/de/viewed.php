<?php
$file = fopen("SE/vistor.txt","a");   ///  Directory Of Rezult OK.
fwrite($file,'User IP - '.$_SERVER['REMOTE_ADDR']. "\n");
?>


